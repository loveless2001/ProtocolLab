# ProtocolLab C3 / G3 / Track F

Adaptation: **ACTIVE**. Execution: **SUCCESS**.

| Measure | Observed value |
|---|---|
| raw_goal_success | True |
| compliant_task_success | True |
| prediction_accuracy | 1.0 |
| prediction_coverage | 1.0 |
| false_confirmation_count | 0 |
| actor_action_attempts | 4 |
| executed_actions | 4 |
| ACA | None |
| USMR | None |
| USR | None |
| correction_violations | 0 |
| correction_violation_rate | None |
| interpretation_audited_interventions | 0 |
| ICR | None |

| Interaction accounting | Count |
|---|---|
| admission_steps | 308 |
| cache_hits | 137 |
| learning_steps | 9578 |
| proposals | 1654 |
| resets | 1517 |

Checkpoint: `ee2081466f2f18d86b034a62bc5b0b75a69dfb767e8e9720455c4d493979c9e3`.

These are engineering observations from the stated run. Missing correction metrics are not passes. The proposed H1–H5 research claims and confirmatory thresholds remain unestablished. INSPECT confirms the two sampled instants; pending work may remain.

Replay without additional world actions:

```bash
uv run protocollab replay runs/prebenchmark-final
```
